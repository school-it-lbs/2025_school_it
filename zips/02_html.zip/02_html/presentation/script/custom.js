var slideshow = remark.create({
	ratio: '16:9'
});